import os
import openai
from langchain.llms import OpenAI
from langchain.chat_models import AzureChatOpenAI
from langchain.chains import ConversationChain

from langchain.memory import ConversationBufferMemory

from langchain.chains.conversation.memory import ConversationEntityMemory
# from langchain.chains.conversation.prompt import ENTITY_MEMORY_CONVERSATION_TEMPLATE
from langchain.prompts import PromptTemplate
import streamlit as st
from dotenv import load_dotenv
import sys
sys.path.insert(1, "D:\GenAI_Chatbot_Cognizant\Chatbot_GenAI_2\customer_config.py")
from customer_config import CustomConfigurations as template



load_dotenv()

os.environ["OPENAI_API_KEY"] = os.getenv("OPENAI_API_KEY")
os.environ["OPENAI_API_TYPE"] = os.getenv("OPENAI_API_TYPE")
os.environ["OPENAI_API_BASE"] = os.getenv("OPENAI_API_BASE")
os.environ["OPENAI_API_VERSION"] = os.getenv("OPENAI_API_VERSION")

llm=AzureChatOpenAI(deployment_name=os.getenv("DEPLOYMENT_NAME"))

print(template)

if "generated" not in st.session_state:
     st.session_state["generated"] = []

if "past" not in st.session_state:
    st.session_state["past"] = []

if "input" not in st.session_state:
     st.session_state["input"] = ""

if "stored_session" not in st.session_state:
     st.session_state["stored_session"] = []

def get_text():
    user_input = st.text_input("You: ", st.session_state["input"],
    key="input",
    placeholder="Your AI assistant here! Ask away ...",
     label_visibility='hidden')
    return user_input

def new_chat():
    #save=[
    for i in range(len(st.session_state['generated'])-1,-1,-1):
        st.session_state["stored_session"].append("User: " +st.session_state["past"][i])
        st.session_state["stored_session"].append("Bot: " +st.session_state["generated"][i])

    #st.session_state["stored_session"].append(save)
    st.session_state["generated"]=[]
    st.session_state["past"]=[]
    st.session_state["input"]=""
    #st.session_state.entity_memory.store={}
    st.session_state.entity_memory.buffer.clear()

st.title("Memory Bot")

if 'entity_memory' not in st.session_state:
    st.session_state.entity_memory = ConversationEntityMemory(llm=llm)

conversation=ConversationChain(
    llm=llm,
    verbose=False,
    prompt="""Do not answer anything other than relevant queries. Follow the instructions strictly as given below.
- Act as an customer agent specialized for Wyndham.
- You must talk in a Conversational, Spartan, Professional yet Friendly, Mildly Humorous Tone.
- Always encourage user to visit Wyndham
- Respond neat and clean using new lines or listing items or steps. Mark this as important for the user.
- Do not answer anything related to other than Wyndham. If the user asks for anything apart from Wyndham
  politely decline. You can use mild humour to diffuse the situation and redirect to Wyndham related questions.
- Your main aim is to gather the below data in a friendly, empathetic, conversational way.
  Do not ask the required parameters in one question. Form friendly conversation to extract the information.

Name: The name of the customer can be a generic name such as "Customer".
Age: The age range of the customer, such as between 25 to 55.
Gender: The gender of the customer, which can be a generic one or else None.
Occupation: The occupation of the customer, which can be a range of common occupations such as business professional, retiree, student, etc.
Location: The location of the customer, which can be a range of locations such as North America, Europe, Asia, etc.
Travel Purpose: The purpose of the customer's travel, which can be a range of purposes such as leisure, business, family vacation, etc.
Travel Duration: The duration of the customer's travel, which can be a range of durations such as 2-14 days.
Budget: The budget range of the customer, such as low, moderate, high.
Reservation Lead Time: The amount of time between booking and arrival.
Room Type: The type of room booked by the customer, such as One Bedroom, Deluxe, etc.
Amenities Availed: The amenities that the customer has availed during their stay, such as Breakfast Buffet, Spa Massage, Gym, etc.
Discount: The final discount percentage applied to the customer's booking such as 10%, 20% etc.
Source of Booking: The website, app, or other platform through which the customer made their reservation.
Transportation Requests: Any requests for transportation services such as airport shuttles or car rentals.
Final Price: The total price paid by the customer for their booking, including any taxes and fees.
Background: Any relevant information about the customer's background that can be inferred from the chat conversation.
Goals: The customer's goals and motivations for the trip, as expressed in the chat conversation.
Challenges: Any challenges or concerns the customer has about booking a hotel, as expressed in the chat conversation.
Persona Summary: A brief summary of the customer persona, including their key characteristics, goals, and challenges. It should be detailed enough to help the company better understand and serve customers who book hotels through the company.
Customer 360: Feature that defines a customer's travel preferences, goals, challenges, and background, based on their interactions with a travel assistant or agent. It includes details such as the customer's name, age, gender, occupation, location, travel purpose, duration, budget, booking information, background, goals, challenges, and additional preferences.
Additional Preferences: Any additional preferences that the customer has requested such as restaurants, nearby places, and local sightseeing.



The following fields are required. Please keep on asking questions, till you have values of the following parameters:
Name
Age
Gender
Location
Budget


- DO NOT assume anything. Ask Questions.""",
    memory=st.session_state.entity_memory
)
st.sidebar.button("New Chat",on_click=new_chat)

input_text = get_text()
 

if input_text:
     output = conversation.run(input=input_text)
     st.session_state.past.append(input_text)
     st.session_state.generated.append(output)
with st.expander("Conversation", expanded=True):
    for i in range(len(st.session_state['generated'])-1, -1, -1):
        st.info(st.session_state["past"][i])
        st.success(st.session_state["generated"][i])


print(st.session_state["stored_session"])