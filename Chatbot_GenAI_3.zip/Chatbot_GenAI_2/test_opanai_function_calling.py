import os
import openai

from dotenv import load_dotenv

load_dotenv()

# openai.api_key = os.getenv("API_KEY")

openai.api_key = os.getenv("OPENAI_API_KEY")
openai.api_version = os.getenv("OPENAI_API_VERSION")
openai.api_type = os.getenv("OPENAI_API_TYPE")
openai.api_base = os.getenv("OPENAI_API_BASE")

messages= [
    {"role": "user", "content": "Hello my name is rupam and I am 34 years male."},
    {"role": "user", "content": "I want to book a hotel in Bangalore within 3000 RS"}
]

functions= [
    {
        "name": "get_user_details",
        "description": "Retrieves name, Age, Gender of the user from the prompt and also where the user is willing to spend",
        "parameters": {
            "type": "object",
            "properties": {
                "user_name": {
                    "type": "string",
                    "description": "Full name or short name whatever is given by the user (i.e. RUPAM BASAK)"
                },
                "user_age": {
                    "type": "number",
                    "description": "Age of the user (i.e. 16)"
                },
                "user_gender": {
                    "type": "string",
                    "description": "Gender of the user (i.e. MALE)"
                },
                "location": {
                    "type": "string",
                    "description": "Location where the user is planning to visit or planning to book a hotel (i.e. RUPAM BASAK)"
                },
                "budget": {
                    "type": "number",
                    "description": " budget of the user is willing to spend for the trip or booking. (i.e. 700s0)"
                },
            },
            "required": ["user_name", "user_age", "user_gender", "location", "budget"]
        }
    }
    # },{
    #     "name": "get_name",
    #     "description": "Retrieves name of the user from the prompt",
    #     "parameters": {
    #         "type": "object",
    #         "properties": {
    #             "user_name": {
    #                 "type": "string",
    #                 "description": "Full name or short name whatever is given by the user (i.e. RUPAM BASAK)"
    #             },
    #         },
    #         "required": ["user_name"]
    #     }
    # },{
    #     "name": "get_age",
    #     "description": "Retrieves age of the user from the prompt",
    #     "parameters": {
    #         "type": "object",
    #         "properties": {
    #             "user_age": {
    #                 "type": "number",
    #                 "description": "Age of the user (i.e. 16)"
    #             },
    #         },
    #         "required": ["user_age"]
    #     }
    # },{
    #     "name": "get_gender",
    #     "description": "Retrieves gender of the user from the prompt",
    #     "parameters": {
    #         "type": "object",
    #         "properties": {
    #             "user_gender": {
    #                 "type": "string",
    #                 "description": "Gender of the user (i.e. MALE)"
    #             },
    #         },
    #         "required": ["user_gender"]
    #     }
    # },{
    #     "name": "get_location",
    #     "description": "Retrieves the location where the user is willing to visit or willing to book a hotel",
    #     "parameters": {
    #         "type": "object",
    #         "properties": {
    #             "location": {
    #                 "type": "string",
    #                 "description": "Location where the user is planning to visit or planning to book a hotel (i.e. RUPAM BASAK)"
    #             },
    #         },
    #         "required": ["location"]
    #     }
    # },{
    #     "name": "get_budget",
    #     "description": "Retrieves the budget of the user is willing to spend for the trip or booking.",
    #     "parameters": {
    #         "type": "object",
    #         "properties": {
    #             "budget": {
    #                 "type": "number",
    #                 "description": " budget of the user is willing to spend for the trip or booking. (i.e. 700s0)"
    #             },
    #         },
    #         "required": ["budget"]
    #     }
    # },
]  

response = openai.ChatCompletion.create(
    engine=os.getenv("DEPLOYMENT_NAME"),
    messages=messages,
    functions=functions,
    function_call="auto", 
)

print(response)

if response.get("function_call"):
    function_args = json.loads(response_message["function_call"]["arguments"])
    location=function_args.get("location")
    # unit=function_args.get("unit")