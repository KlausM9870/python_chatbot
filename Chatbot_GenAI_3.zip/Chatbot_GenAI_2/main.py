import os
from flask import Flask
from flask_cors import CORS
from flask import request
from flask import jsonify
import urls as url
import sys
import requests
from dotenv import load_dotenv
load_dotenv()
sys.path.insert(1, os.getenv('controllers_path'))
import chat_controller_new as chat_controller


app = Flask(__name__)
CORS(app)


@app.route(url.CHAT_URL, methods=["POST"])
def chat_with_llm():
    try:
        initiate_chat_prompt = 'Introduce yourself and ask very professionally, politely and friendly way if user need any help from you.'

        if request.json['initiate'] == True:
            response = chat_controller.chat(True, initiate_chat_prompt, 'CHAT')
        else:
            response = chat_controller.chat(False, request.json['prompt'], 'CHAT')
        return jsonify(response)
        
    except Exception as err:
        print(err)

@app.route(url.JIRA_URL, methods=["POST"])
def chat_with_llm_for_jira():
    try:
        initiate_chat_prompt = 'Introduce yourself and ask very professionally, politely and friendly way if user need any help from you.'

        if request.json['initiate'] == True:
            response = chat_controller.chat(True, initiate_chat_prompt, 'JIRA')
        else:
            response = chat_controller.chat(False, request.json['prompt'], 'JIRA')
        return jsonify(response)
        
    except Exception as err:
        print(err)

@app.route(url.JIRA_ISSUE_URL, methods=["GET"])
def jira_issue_create():
    try:
        # Jira instance URL and API credentials
        jira_url = "https://optimizer007.atlassian.net"
        api_username = "sudeept.2409@gmail.com"
        api_password = "ATATT3xFfGF09F1mmJQUoEMItsc1IjdGVnJ1mrvMEjD_yyp0D5jrnxXyFyyt9OEqDYQEchWhtZR2Da74EPdMaW9QOVOMYjuQfh0hw3MO45d60frxxVjFnqZOG931K1oUqdLxtsiQ2AzJWlhggxp8EqXze7o1uQ8VeRq3nywNHMWWcQGG93bhfVM=C790CBBB"

        # Define the issue details
        issue_data = (
            "{"
            '"fields": {'
            '"project": {'
            '"key": "OP"'
            "},"
            '"summary": "Test issue Live",'
            '"description": "This is an example issue created via the Jira REST API",'
            '"issuetype": {'
            '"name": "Bug"'
            "}"
            "}"
            "}"
        )

        # Make a POST request to create the issue
        response = requests.post(
            f"{jira_url}/rest/api/2/issue",
            auth=(api_username, api_password),
            headers={"Content-Type": "application/json"},
            data=issue_data.encode("utf-8")
        )

        # Check if the request was successful
        if response.status_code == 201:
            # Parse the response text
            issue = response.json()
            issue_key = issue["key"]
            print(f"Issue created: {issue_key}")
            url1 = jira_url + "/browse/" + issue_key
            print(f"Issue Link: {url1}")
            return {"res_code": response.status_code,
                    "url": url1}
        else:
            # Print the error message
            print(f"Error creating issue:{response.json()}")
            return response.json()

    except Exception as err:
        print(err)