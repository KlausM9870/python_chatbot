import os
from dotenv import load_dotenv
load_dotenv()
from langchain.chat_models import AzureChatOpenAI
from langchain.chains import ConversationChain
from langchain.memory import ConversationBufferMemory
from langchain.prompts import PromptTemplate
import sys
sys.path.insert(1, os.getenv('hotel_config_path'))
sys.path.insert(1, os.getenv('jira_config_path'))
from customer_config import CustomConfigurations
from jira_config import CustomConfigurations as JiraConfigurations
import parameter_extraction_controller

os.environ["OPENAI_API_KEY"] = os.getenv("OPENAI_API_KEY")
os.environ["OPENAI_API_TYPE"] = os.getenv("OPENAI_API_TYPE")
os.environ["OPENAI_API_BASE"] = os.getenv("OPENAI_API_BASE")
os.environ["OPENAI_API_VERSION"] = os.getenv("OPENAI_API_VERSION")

llm=AzureChatOpenAI(deployment_name=os.getenv("DEPLOYMENT_NAME"))
memory=ConversationBufferMemory(llm=llm)
user_prompts_str = ''

def chat(initiate, user_prompt, config):
    global user_prompts_str
    try:
        if initiate:
            memory.clear()
            user_prompts_str = ''
        
        template_model = CustomConfigurations if config == 'CHAT' else JiraConfigurations + '''

        This is the history of the conversation below:
        {history}

        Current conversation as below:
        Human: {input}
        AI: '''

        default_template = PromptTemplate(
            input_variables=["history", "input"],
            template=template_model,
        )

        conversation = ConversationChain(
            llm=llm, 
            verbose=True,
            prompt=default_template,
            memory=memory
        )

        if memory.load_memory_variables({})['history'] != '':
            ai_output = conversation.predict(input=user_prompt)
            # print('INSIDE IFFFF')
            user_prompts_str = user_prompts_str  + user_prompt + '. '
            # print('user_prompts_str---------->>>>>>>>>', user_prompts_str)
            extracted = parameter_extraction_controller.extarct_parameters_from_user_prompts(user_prompts_str, config)
            print('extracted', extracted)
            return { "response": ai_output, "extracted": extracted, "history": memory.load_memory_variables({})['history'] }
        else:
            # print('INSIDE ELSE')
            ai_output = conversation.predict(input=user_prompt)
            return { "response": ai_output, "extracted": {}, "history": memory.load_memory_variables({})['history'] }
    except Exception as err:
        print('HERE_Chat_Cont', err)