import os
import openai
import json
from dotenv import load_dotenv

load_dotenv()

openai.api_key = os.getenv("OPENAI_API_KEY")
openai.api_version = os.getenv("OPENAI_API_VERSION")
openai.api_type = os.getenv("OPENAI_API_TYPE")
openai.api_base = os.getenv("OPENAI_API_BASE")



def extarct_parameters_from_user_prompts(conversation_history, configuration):
    try:
        if configuration == 'CHAT':
                functions = [
                    {
                        "name": "get_user_details",
                        "description": "Retrieves name, Age, Gender of the user from the prompt and also where the user is willing to spend",
                        "parameters": {
                            "type": "object",
                            "properties": {
                                "user_name": {
                                    "type": "string",
                                    "description": "Full name or short name whatever is given by the user (i.e. RUPAM BASAK)"
                                },
                                "user_age": {
                                    "type": "number",
                                    "description": "Age of the user (i.e. 16)"
                                },
                                "user_gender": {
                                    "type": "string",
                                    "description": "Gender of the user (i.e. MALE)"
                                },
                                "location": {
                                    "type": "string",
                                    "description": "Location where the user is planning to visit or planning to book a hotel (i.e. Kolkata)"
                                },
                                "budget": {
                                    "type": "number",
                                    "description": " budget of the user is willing to spend for the trip or booking. This cannot be zero (i.e. 7000)"
                                },
                            },
                            "required": ["user_name", "user_age", "user_gender", "location", "budget"]
                        }
                    }
                ]
        elif configuration == 'JIRA':
                functions = [
                    {
                        "name": "create_jira_stroy",
                        "description": "Creates a JIRA story with title, description, summary, project key, story point, issue type",
                        "parameters": {
                            "type": "object",
                            "properties": {
                                "title": {
                                    "type": "string",
                                    "description": "Title of the JIRA story"
                                },
                                "description": {
                                    "type": "number",
                                    "description": "description of the JIRA story"
                                },
                                "summary": {
                                    "type": "string",
                                    "description": "Summary of the JIRA story"
                                },
                                "project_key": {
                                    "type": "string",
                                    "description": "a unique key in string value for JIRA story"
                                },
                                "story_point": {
                                    "type": "number",
                                    "description": "How many points required for the JIRA story"
                                },
                                "issue_type": {
                                    "type": "string",
                                    "description": "The type of the JIRA story"
                                },
                            },
                            "required": ["Title", "Summary", "Description", "Project Key", "Story Points" ,"Issue Type"]
                        }
                    }
                ]
                
       
        messages = [{ "role": "user", "content": conversation_history }]
        print("messagesmessagesmessages ------", messages)
        response = openai.ChatCompletion.create(
            engine=os.getenv("DEPLOYMENT_NAME"),
            messages=messages,
            functions=functions,
            function_call="auto", 
            temperature = 0.5,
        )

        # print("response", response.choices[0].message)

        if "function_call" in response.choices[0].message.keys():
            function_args = json.loads(response.choices[0].message["function_call"]["arguments"])
            print('EXTRACTED ---', function_args)
            return { "extarcted": True, "extracted_data": function_args}

        else:
            print('NOT EXTRACTED ---')
            return { "extarcted": False, "extracted_data": {}}
    except Exception as err:
        print('HERE parameter_extraction', err)
# extarct_parameters_from_user_prompts("Hello agent, i want to book a flight.. Okay then can you please help me to book a wyndham hotel in Pune?. I am Akash, 20yrs, Male.. ")
        # },{
        #     "name": "get_name",
        #     "description": "Retrieves name of the user from the prompt",
        #     "parameters": {
        #         "type": "object",
        #         "properties": {
        #             "user_name": {
        #                 "type": "string",
        #                 "description": "Full name or short name whatever is given by the user (i.e. RUPAM BASAK)"
        #             },
        #         },
        #         "required": ["user_name"]
        #     }
        # },{
        #     "name": "get_age",
        #     "description": "Retrieves age of the user from the prompt",
        #     "parameters": {
        #         "type": "object",
        #         "properties": {
        #             "user_age": {
        #                 "type": "number",
        #                 "description": "Age of the user (i.e. 16)"
        #             },
        #         },
        #         "required": ["user_age"]
        #     }
        # },{
        #     "name": "get_gender",
        #     "description": "Retrieves gender of the user from the prompt",
        #     "parameters": {
        #         "type": "object",
        #         "properties": {
        #             "user_gender": {
        #                 "type": "string",
        #                 "description": "Gender of the user (i.e. MALE)"
        #             },
        #         },
        #         "required": ["user_gender"]
        #     }
        # },{
        #     "name": "get_location",
        #     "description": "Retrieves the location where the user is willing to visit or willing to book a hotel",
        #     "parameters": {
        #         "type": "object",
        #         "properties": {
        #             "location": {
        #                 "type": "string",
        #                 "description": "Location where the user is planning to visit or planning to book a hotel (i.e. RUPAM BASAK)"
        #             },
        #         },
        #         "required": ["location"]
        #     }
        # },{
        #     "name": "get_budget",
        #     "description": "Retrieves the budget of the user is willing to spend for the trip or booking.",
        #     "parameters": {
        #         "type": "object",
        #         "properties": {
        #             "budget": {
        #                 "type": "number",
        #                 "description": " budget of the user is willing to spend for the trip or booking. (i.e. 700s0)"
        #             },
        #         },
        #         "required": ["budget"]
        #     }
        # },
    # ]  
    # print('user_prompt_dict ---', conversation_history)
    