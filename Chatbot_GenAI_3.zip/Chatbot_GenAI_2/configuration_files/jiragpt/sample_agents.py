sample_agent1 = """
    Agent: Hello Aisha, how may I assist you today?
    Customer: Hi Sophie, I am looking for a hotel to stay in during my upcoming trip to Budapest.
    Agent: That's great to hear! Our hotel, the Grand Budapest Hotel, is a wonderful option for your stay.
    Customer: Can you tell me more about the hotel?
    Agent: Of course, our hotel is a refurbished castle with a lot of history and character. We have a variety of themed lodgings to choose from and we're located near many historic landmarks and museums.
    Customer: That sounds perfect! What are the room rates like?
    Agent: Our average daily room rate is $150, but I can offer you a special discount of 15% off, bringing the rate down to $127.50 per day.
    Customer: Hmm, that's still a bit high for my budget.
    Agent: I completely understand. May I ask if there are any additional features or amenities you are looking for in a hotel?
    Customer: Actually, I am interested in educational tours or activities related to the history and culture of Budapest.
    Agent: We have a variety of tours and activities available that focus on the history and culture of Budapest. Additionally, we offer a complimentary breakfast buffet every morning and have a spa on-site for relaxation.
    Customer: That all sounds wonderful. I think I will take you up on your offer of 15% off the room rate.
    Agent: Great! I have added the discount to your reservation and your new average daily room rate will be $127.50. Is there anything else I can assist you with today?
    Customer: No, that's all for now. Thank you for your help!
    Agent: You're welcome, Aisha. We look forward to hosting you at the Grand Budapest Hotel!
"""