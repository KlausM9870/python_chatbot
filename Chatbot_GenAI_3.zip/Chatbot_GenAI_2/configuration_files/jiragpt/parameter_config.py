jiragpt_param_config = """
Title :
Summary :
Description :
Project Key :
Story Points :
Issue Type :
"""
 
jiragpt_require_param_config = """
    The following fields are required. Please keep on asking questions, till you have values of the following parameters:
    Title
    Summary
    Description
    Project Key
    Story Points
    Issue Type
"""