wyndham_param_config = """
Name: The name of the customer can be a generic name such as "Customer".
Age: The age range of the customer, such as between 25 to 55.
Gender: The gender of the customer, which can be a generic one or else None.
Occupation: The occupation of the customer, which can be a range of common occupations such as business professional, retiree, student, etc.
Location: The location of the customer, which can be a range of locations such as North America, Europe, Asia, etc.
Travel Purpose: The purpose of the customer's travel, which can be a range of purposes such as leisure, business, family vacation, etc.
Travel Duration: The duration of the customer's travel, which can be a range of durations such as 2-14 days.
Budget: The budget range of the customer, such as low, moderate, high.
Reservation Lead Time: The amount of time between booking and arrival.
Room Type: The type of room booked by the customer, such as One Bedroom, Deluxe, etc.
Amenities Availed: The amenities that the customer has availed during their stay, such as Breakfast Buffet, Spa Massage, Gym, etc.
Discount: The final discount percentage applied to the customer's booking such as 10%, 20% etc.
Source of Booking: The website, app, or other platform through which the customer made their reservation.
Transportation Requests: Any requests for transportation services such as airport shuttles or car rentals.
Final Price: The total price paid by the customer for their booking, including any taxes and fees.
Background: Any relevant information about the customer's background that can be inferred from the chat conversation.
Goals: The customer's goals and motivations for the trip, as expressed in the chat conversation.
Challenges: Any challenges or concerns the customer has about booking a hotel, as expressed in the chat conversation.
Persona Summary: A brief summary of the customer persona, including their key characteristics, goals, and challenges. It should be detailed enough to help the company better understand and serve customers who book hotels through the company.
Customer 360: Feature that defines a customer's travel preferences, goals, challenges, and background, based on their interactions with a travel assistant or agent. It includes details such as the customer's name, age, gender, occupation, location, travel purpose, duration, budget, booking information, background, goals, challenges, and additional preferences.
Additional Preferences: Any additional preferences that the customer has requested such as restaurants, nearby places, and local sightseeing.

"""


wyndham_require_param_config = """
The following fields are required. Please keep on asking questions, till you have values of the following parameters:
Name
Age
Gender
Location
Budget
"""