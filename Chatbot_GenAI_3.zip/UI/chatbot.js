/**
 * @returns void
 */
function sendUserMsg() {
  let prompt = document.getElementById("typing").value;
  if (prompt) {
    let chat_area = document.getElementById("conversation_area");
    let elem = document.createElement("div");
    elem.setAttribute("class", "conversation user_prompt row");
    elem.innerHTML = `
        <div class="col-2 roles">
        <div class="user_icon icon">User</div>
        <span>${getTime(0)}</span>
        </div>
        <div class="col-10">
        ${convertTextToHTML(prompt)}
        </div>
        `;
    chat_area.appendChild(elem);
    document.getElementById("typing").value = "";
    scrollBottom();
    showAIResponse(prompt);
  }
  clearChatArea();
}

/**
 * @method convertTextToHTML is responsible to convert the new lines to html break tags
 * @param t is the argument sent
 * @returns the text with <br> tag
 */
function convertTextToHTML(t) {
  let text = t.replace(/(?:\r\n|\r|\n)/g, "<br>");
  console.log(text);
  return text;
}

/**
 *
 * @returns current time
 */
function getTime() {
  let time = new Date();
  time = `${time.getHours() < 10 ? "0" + time.getHours() : time.getHours()}:${
    time.getMinutes() < 10 ? "0" + time.getMinutes() : time.getMinutes()
  }:${time.getSeconds() < 10 ? "0" + time.getSeconds() : time.getSeconds()}`;
  return time;
}

/**
 *
 * @param user_prompt is passed to /chat api
 */
function showAIResponse(user_prompt) {
  let str_random = generateString(10);
  let chat_area = document.getElementById("conversation_area");
  let elem = document.createElement("div");
  elem.setAttribute("class", "conversation bot_response row");
  elem.innerHTML = `<div class="col-2 roles ai">
          <div class="ai_icon icon">Bot</div>
          <span style="position: relative; width: 60%; text-align: center">
            <span id="${str_random}_showTime" style="display: none"></span>
            <span id="${str_random}_loader_spinner" class="loader" style="width: 25px; height: 25px; position: absolute; top: -5px; left: -10px; display: block"></span>
            <span id="${str_random}_loader_text" style="font-weight: lighter; font-size: 10px; margin-left: 5px; display: block">Generating</span>
          </span>
        </div>
        <div id="${str_random}_response" class="col-10" style="position: relative; border-left: 1px solid grey;">
        </div>`;
  chat_area.appendChild(elem);
  scrollBottom();
  axios({
    method: "post",
    url: "http://localhost:5000/jira",
    headers: {
      "session-id": sessionStorage.getItem("session-id"),
    },
    data: {
      prompt: user_prompt,
      initiate: false,
    },
  })
    .then(function (response) {
      callApi(str_random, response.data.response);
    })
    .catch(function (err) {
      console.log(err);
    });
}

/**
 *
 * @param str_random is passed for setting them with the AI response ids in html, to easily distinguise b/w them occuring multiple times
 * @param {*} ai_response
 */
function callApi(str_random, ai_response) {
  let time_span = document.getElementById(`${str_random}_showTime`);
  let spinner = document.getElementById(`${str_random}_loader_spinner`);
  let txt = document.getElementById(`${str_random}_loader_text`);
  let resp_area = document.getElementById(`${str_random}_response`);
  spinner.style.display = "none";
  txt.style.display = "none";
  time_span.style.display = "block";
  time_span.innerHTML = `${getTime()}`;
  let resp = convertTextToHTML(ai_response);
  resp_area.innerHTML = resp;
  scrollBottom();
}

/**
 *
 * @param length is required to create random string with that length
 * @returns random string of length 'length'
 */
function generateString(length) {
  const characters =
    "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
  let result = "";
  const charactersLength = characters.length;
  for (let i = 0; i < length; i++) {
    result += characters.charAt(Math.floor(Math.random() * charactersLength));
  }
  return result;
}

/**
 * responsible to bring the scroll to the bottom for the chatbot
 */
function scrollBottom() {
  document.getElementById("conversation_area").scrollTo({
    top: document.getElementById("conversation_area").scrollHeight,
  });
}

/**
 * clears the chat area after user sends the message
 */
function clearChatArea() {
  if (document.querySelectorAll(".roles").length > 0) {
    document.getElementById("starting_text").style.display = "none";
  }
}

/**
 * creates session by calling @method generateString() and set it to the session id
 */
function createSession() {
  sessionStorage.setItem(
    "session-id",
    generateString(3) + "_" + generateString(4)
  );
  initiateConversation();
}
createSession(); // calling the function initally

function initiateConversation() {
  let str_random = generateString(10);
  let chat_area = document.getElementById("conversation_area");
  let elem = document.createElement("div");
  elem.setAttribute("class", "conversation bot_response row");
  elem.innerHTML = `<div class="col-2 roles ai">
          <div class="ai_icon icon">Bot</div>
          <span style="position: relative; width: 60%; text-align: center">
            <span id="${str_random}_showTime" style="display: none"></span>
            <span id="${str_random}_loader_spinner" class="loader" style="width: 25px; height: 25px; position: absolute; top: -5px; left: -10px; display: block"></span>
            <span id="${str_random}_loader_text" style="font-weight: lighter; font-size: 10px; margin-left: 5px; display: block">Generating</span>
          </span>
        </div>
        <div id="${str_random}_response" class="col-10" style="position: relative; border-left: 1px solid grey;">
        </div>`;
  chat_area.appendChild(elem);
  scrollBottom();
  axios({
    method: "post",
    url: "http://localhost:5000/jira",
    headers: {
      "session-id": sessionStorage.getItem("session-id"),
    },
    data: {
      prompt: "",
      initiate: true,
    },
  })
    .then(function (response) {
      callApi(str_random, response.data.response);
    })
    .catch(function (err) {
      console.log(err);
    });
}

function newChat() {
  sessionStorage.removeItem("session-id");
  document.getElementById("conversation_area").innerHTML = "";
  createSession();
}
